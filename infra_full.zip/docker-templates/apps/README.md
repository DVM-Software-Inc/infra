App template docker-compose lives here.
