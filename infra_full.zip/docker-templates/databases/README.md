Database docker-compose templates: Postgres, MongoDB, MSSQL.
