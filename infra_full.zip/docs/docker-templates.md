# Docker Templates Overview

- `docker-templates/traefik` — Traefik reverse proxy stack
- `docker-templates/nginx` — NGINX reverse proxy stack
- `docker-templates/apps` — App docker-compose template for Traefik
- `docker-templates/databases` — Postgres, MongoDB, MSSQL templates
