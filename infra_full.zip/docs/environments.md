# Environments

We use two primary environments:

- `dev`  → development VPS, branch `dev`
- `prod` → production VPS, branch `main`

Each environment in GitHub stores:

- `VPS_HOST`
- `VPS_USER`
- `VPS_SSH_KEY`
- `DOMAIN_ROOT`
- `GHCR_USERNAME`
- `GHCR_TOKEN`
