# Repository Conventions

- Backends:
  - `backend-go-<name>`
  - `backend-fastapi-<name>`
  - `backend-dotnet-<name>`
  - `backend-django-<name>`

- Frontends:
  - `frontend-nextjs-<name>`
  - `frontend-svelte-<name>`
  - `frontend-vue-<name>`
  - `frontend-angular-<name>`
