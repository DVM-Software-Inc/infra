# Versioning

Images are tagged as:

- `<env>-latest` e.g. `dev-latest`, `prod-latest`
- Optional semantic tags: `v1.0.0`, `v1.0.1`, etc.
