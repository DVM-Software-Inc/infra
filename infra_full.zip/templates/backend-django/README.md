Django backend template placeholder. Extend as needed.
