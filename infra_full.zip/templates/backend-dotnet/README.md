ASP.NET Core backend template placeholder. Extend as needed.
