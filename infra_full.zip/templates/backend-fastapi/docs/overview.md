# FastAPI Backend Template — DVM Software

- Entry: `src/main.py`
- Health endpoint: `GET /health/`
- Runs on port 8000 internally.
