Angular frontend template placeholder. Extend as needed.
