Next.js frontend template placeholder. Extend as needed.
