SvelteKit frontend template placeholder. Extend as needed.
