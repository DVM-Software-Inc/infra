Vue frontend template placeholder. Extend as needed.
